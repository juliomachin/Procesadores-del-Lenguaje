import java.util.Scanner;
import java.util.regex.Pattern;
/**
 * 
 * @author Julio Machin Ruiz
 *
 *	Practica 1 expresion_esiones Regulares
 */
public class Expresiones_Regulares {

	public static void main(String[] args) {
		/**
		 * Hacemos un bucle do-while, para facilitar la opci�n de menu del programa,
		 * dado el valor introducido por el usuario podremos ejecutar cada una de las opciones.
		 * 
		 */
		int opcion = 0;
		do {
			System.out.println("Elige la opcion que quieres utlizar: \n\t1-Validar el formato de un DNI o un NIE\n\t2-Numero real con exponente\n\t3-Nombre de dominio en Internet\n\t4-Correo electr�nico\n\t5-Identificador\n\t0-Salir");
			Scanner sc = new Scanner(System.in);
			opcion = sc.nextInt();
			switch(opcion) {
			/**
			 * Caso 0, para la ejecuci�n del analizador.
			 */
			case 0:
				System.out.println("Hasta la proxima!");
				break;
				/**
				 * Caso 1, valida el formato del DNI O NIE.
				 * Guardamos el dato de entrada en la variable input.
				 * En la variable expresion_1, guardamos las opciones que aceptamos como validas:
				 * 		La primera de las opciones son 8 digitos numericos seguido de una de las letras entre A-H, J-N, P-T o V-Z.
				 * 		La segunda de las opciones seria comenzar con X, Y o Z, seguido de 7 digitos y una de las letras A-H, J-N, P-T o V-Z.
				 * A continuaci�n, comparamos lo introducido por teclado 'input' con una de las opciones validas 'expresion_1'
				 * si es correcta o no los lo dira el programa comparando el resultado en el if.
				 */
			case 1:
				System.out.println("Introduce el texto a analizar:");
				sc = new Scanner(System.in);
				String input = sc.nextLine();
				String expresion_1 = "(\\d{8}([A-H]|[J-N]|[P-T]|[V-Z]))|([X|Y|Z]\\d{7}([A-H]|[J-N]|[P-T]|[V-Z]))";
				boolean resultado = Pattern.matches(expresion_1, input);
				if (resultado) {
					System.out.println("El texto introducido es correcto.");
					System.out.println();
				}else {
					System.out.println("El texto introducido no es valido.");
					System.out.println();
				}
				break;


				/**
				 * Caso 2, valida un numero real con exponente.
				 * Guardamos el dato de entrada en la variable input.
				 * En la variable expresion_2, guardamos las opciones que aceptamos como validas:
				 * 		El primer bloque [-+]? est� indicando que el n�mero podr�a estar precedido opcionalmente de un signo - o un signo +
				 * 		El segundo bloque [0-9]* indica que podr�a aparecer un n�mero de 0 o m�s d�gitos del 0 al 9
				 * 		El tercer bloque indica que tambi�n de manera opcional podr�a aparecer un punto decimal
				 * 		El cuarto bloque sugiere la aparici�n de un n�mero de 1 o m�s d�gitos del 0 al 9 
				 * 		El quinto bloque es precisamente el que indicar�a la parte exponencial del n�mero.
				 * 		El quinto bloque lo dividimos en sub-bloques:
				 * 			Un primer bloque que indica la aparici�n de la letra 'e' o 'E' de exponente.
				 * 			Un segundo bloque que indica la aparici�n opcional del signo '-' o el signo '+'
				 * 			Un tercer bloque que indica la aparici�n de un n�mero de 1 o m�s d�gitos del 0 al 9.
				 * A continuaci�n, comparamos lo introducido por teclado 'input' con una de las opciones validas 'expresion_2'
				 * si es correcta o no los lo dira el programa comparando el resultado en el if.
				 */
			case 2:
				System.out.println("Introduce el texto a analizar:");
				sc = new Scanner(System.in);
				input = sc.nextLine();
				String expresion_2 = "[-|+]?[0-9]*\\.?[0-9]+([e|E][-|+]?[0-9]+)?";
				resultado = Pattern.matches(expresion_2, input);
				if (resultado) {
					System.out.println("El texto introducido es correcto.");
					System.out.println();
				}else {
					System.out.println("El texto introducido no es valido.");
					System.out.println();
				}
				break;
			
				/**
				 * Caso 3, valida el nombre de un dominio en internet.
				 * Guardamos el dato de entrada en la variable input.
				 * En la variable expresion_3, guardamos las opciones que aceptamos como validas:
				 * 		El primer bloque ([a-z]+ compara que por lo menos haya minimo una vez una letra entre a y z.
				 * 		El segundo bloque \\.)+  compara que haya como minimo un punto junto al bloque 1 y 3
				 * 		El tercer bloque ([a-z]+ compara que por lo menos haya minimo una vez una letra entre a y z.
				 * A continuaci�n, comparamos lo introducido por teclado 'input' con una de las opciones validas 'expresion_3'
				 * si es correcta o no los lo dira el programa comparando el resultado en el if.
				 */
				
				
			case 3:
				System.out.println("Introduce el texto a analizar:");
				sc = new Scanner(System.in);
				input = sc.nextLine();
				String expresion_3 = "(([a-z]+)\\.)+([a-z]+)";
				resultado = Pattern.matches(expresion_3, input);
				if (resultado) {
					System.out.println("El texto introducido es correcto.");
					System.out.println();
				}else {
					System.out.println("El texto introducido no es valido.");
					System.out.println();
				}
				break;
				
				
				
				/**
				 * Caso 4, valida el nombre de un dominio en internet.
				 * Guardamos el dato de entrada en la variable input.
				 * En la variable expresion_4, guardamos las opciones que aceptamos como validas:
				 * 		El primer bloque [_]|[a-z]|[0-9]|[-]) compara que por lo menos haya un elemento de _ o una letra entre la a y la z o un numero de 0 al 9 o un -.
				 * 		El segundo bloque [_]|[a-z]|[0-9]|[-]) compara que despues de un elemento '.' por lo menos haya un elemento de _ o una letra entre la a y la z o un numero de 0 al 9 o un -.
				 * 		El tercer bloque [_]|[a-z]|[0-9]|[-]) compara que despues de un elemento '@' por lo menos haya un elemento de _ o una letra entre la a y la z o un numero de 0 al 9 o un -.
				 * A continuaci�n, comparamos lo introducido por teclado 'input' con una de las opciones validas 'expresion_4'
				 * si es correcta o no los lo dira el programa comparando el resultado en el if.
				 */
		
			case 4:
				System.out.println("Introduce el texto a analizar:");
				sc = new Scanner(System.in);
				input = sc.nextLine();
				String expresion_4 = "([_]|[a-z]|[0-9]|[-])+(.[_]|[a-z]|[0-9]|[-])@(([a-z]+)\\.)+([a-z]+)";
				resultado = Pattern.matches(expresion_4, input);
				if (resultado) {
					System.out.println("El texto introducido es correcto.");
					System.out.println();
				}else {
					System.out.println("El texto introducido no es valido.");
					System.out.println();
				}
				break;
				
				
				/**
				 * Caso 5, valida el nombre de un dominio en internet.
				 * Guardamos el dato de entrada en la variable input.
				 * En la variable expresion_5, guardamos las opciones que aceptamos como validas:
				 * 		El primer bloque ([A-Z]|[a-z]|[_])+ compara que el primer dijito sea un letra entre la a-z mayuscula o minuscula o una barra baja '_' y el '+' nos dice que puede haber un elemento como minimo.
				 * 		El segundo bloque ([A-Z]|[a-z]|[_])* compara que el dijito introducido despues del primer bloque sea a-z mayuscula o minuscula o una barra baja '_' y el '*' nos dice que puede haber entre 0 y todos los elementos posibles.
				 * A continuaci�n, comparamos lo introducido por teclado 'input' con una de las opciones validas 'expresion_5'
				 * si es correcta o no los lo dira el programa comparando el resultado en el if.
				 */
				
			case 5:
				System.out.println("Introduce el texto a analizar:");
				sc = new Scanner(System.in);
				input = sc.nextLine();
				String expresion_5 = "([A-Z]|[a-z]|[_])+([A-Z]|[a-z]|[_]|[0-9])*";
				resultado = Pattern.matches(expresion_5, input);
				if (resultado) {
					System.out.println("El texto introducido es correcto.");
					System.out.println();
				}else {
					System.out.println("El texto introducido no es valido.");
					System.out.println();
				}
				break;
				
				/**
				 * Default, en caso de introducir un numero distinto de los del menu devuelve un mensaje de error y te solicita un nuevo.
				 */
			default:
				System.out.println("Error al introducir el dato.");
				break;
			}
		}while(opcion!=0);

	}


}




